# Marea
Icons for deepin version 5.3.1
Marea icons and cursor theme are designed to be used in Deepin OS,
Icons created by Car and maintained by Deepin in Spanish community http://www.deepinenespañol.org
Licensed under GPLv3 compatible.
